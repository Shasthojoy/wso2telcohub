package com.dialog.mife.ussd.dto;

public enum USSDAction {
	moinit, mocont, mtinit, mtcont, mtfin;
}
