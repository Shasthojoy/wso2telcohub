package com.dialog.mife.ussd.dto;

public enum ApplicationStatus {
	ACTIVE, SUSPENDED, DELETED
}
