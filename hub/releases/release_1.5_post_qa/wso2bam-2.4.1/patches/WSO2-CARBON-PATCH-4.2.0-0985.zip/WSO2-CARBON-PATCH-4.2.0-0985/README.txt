Patch ID         : WSO2-CARBON-PATCH-4.2.0-0985
Applies To       : Business Activity Monitor 2.4.1
Associated JIRA  : https://wso2.org/jira/browse/BAM-1932


DESCRIPTION
-----------
This patch fix the connection leak happens due to cassandra connections make from analytics components when the incremental data processing is enabled.


INSTALLATION INSTRUCTIONS
-------------------------

(i)  Shutdown the server, if you have already started.

(ii) Copy the wso2carbon-version.txt file to <CARBON_SERVER>/bin.

(iii) Copy the patch0985 to  <CARBON_SERVER>/repository/components/patches/

(iv) Restart the server with :
       Linux/Unix :  sh wso2server.sh
       Windows    :  wso2server.bat

