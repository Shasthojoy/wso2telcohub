Patch ID         : WSO2-CARBON-PATCH-4.2.0-0765
Applies To       : WSO2 BAM 2.4.1
Associated JIRA  : https://wso2.org/jira/browse/BAM-1747


DESCRIPTION
-----------
This patch resolves the problem existing in DataPublisher closing the connection and results in having many connections made with BAM/CEP server. And also when connecting BAM/CEP server wrong protocols and wrong ports (SSL -> 7611, where as SSL port is 7711 and 7611 is TCP port), then it will not lead to OOM error and rather it'll log the error message. 


INSTALLATION INSTRUCTIONS
-------------------------

(i)  Shutdown the server, if you have already started.

(ii) Copy the wso2carbon-version.txt file to <CARBON_SERVER>/bin.

(iii) Copy the patch0765 to  <CARBON_SERVER>/repository/components/patches/

(iv) Restart the server with :
       Linux/Unix :  sh wso2server.sh
       Windows    :  wso2server.bat

