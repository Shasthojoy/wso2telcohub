Patch ID         : WSO2-CARBON-PATCH-4.2.0-0401
Applies To       : WSO2 BAM 2.4.1
Associated JIRA  : https://wso2.org/jira/browse/BAM-1663


DESCRIPTION
-----------
This patch is a performance improvement patch, which basically uses cache for the streamDefintionStore and avoids the accessing the stream defintion store to get the actual stream defintion for each event.


INSTALLATION INSTRUCTIONS
-------------------------

(i)  Shutdown the server, if you have already started.

(ii) Copy the wso2carbon-version.txt file to <CARBON_SERVER>/bin.

(iii) Copy the patch0401 to  <CARBON_SERVER>/repository/components/patches/

(iv) Restart the server with :
       Linux/Unix :  sh wso2server.sh
       Windows    :  wso2server.bat

