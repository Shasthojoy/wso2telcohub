Patch ID         : WSO2-CARBON-PATCH-4.2.0-0832
Applies To       : Identity Server 5.0.0
Associated JIRA  : https://wso2.org/jira/browse/IDENTITY-2800, https://wso2.org/jira/browse/IDENTITY-2817


DESCRIPTION
-----------
Remove Line breaks from openid ID Token and include signing capability, Correcting openid connect IDToken properties (oauth_time, exp, iat)


INSTALLATION INSTRUCTIONS
-------------------------

(i)  Shutdown the server, if you have already started.

(ii) Copy the wso2carbon-version.txt file to <CARBON_SERVER>/bin.

(iii) Copy the patch0832 to  <CARBON_SERVER>/repository/components/patches/

(v) Delete <CARBON_SERVER>/repository/deployment/server/webapps/oauth2, <CARBON_SERVER>/repository/deployment/server/webapps/oauth2.war  

(vi) Copy /resources/webapps/oauth2.war to <CARBON_SERVER>/repository/deployment/server/webapps

(vii) Restart the server with :
       Linux/Unix :  sh wso2server.sh
       Windows    :  wso2server.bat

