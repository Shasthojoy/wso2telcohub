Patch ID         : WSO2-CARBON-PATCH-4.2.0-0777
Applies To       : IS 5.0.0
Associated JIRA  : https://wso2.org/jira/browse/IDENTITY-2766


DESCRIPTION
-----------
This is a patch which includes all the patches we have done so far for IS 5.0.0.

INSTALLATION INSTRUCTIONS
-------------------------

(i)  Shutdown the server, if you have already started.

(ii) Copy the wso2carbon-version.txt file to <CARBON_SERVER>/bin.

(iii) Copy the patch777 to <CARBON_SERVER>/repository/components/patches/

(iv) Copy oauth2.war and wso2.war files inside resources/webapps folder to <CARBON_SERVER>/repository/deployment/server/webapps/ folder.(replace what is already there.)

(v) Copy the sql script files inside resources/identity folder to <CARBON_SERVER>/repository/dbscripts/identity folder. (replace what is already there.)

(vi) Enable following parameter in <carbon_home>/repository/conf/security/application-authentication.xml file if you only need customized error messages in Idenity management feature. Otherwise skip this step 
         
	<AuthenticatorConfig name="BasicAuthenticator" enabled="true"> 
		<Parameter name="showAuthFailureReason">true</Parameter>	
	</AuthenticatorConfig> 

   There are three types of custom errors handle here 

	    * Invalid credentials 
	    * Invalid User 
	    * Account Lock

   We send following query parameters to Authentication endpoint webapp and you can customize the error Messages according to errorCode. You can use [1] for error code descriptions. 

	    * ErrorCode 
	    * failedUsername 
	    * remainingAttempts 

vii) Add the following configuration to <CARBON_SERVER>/repository/conf/security/application-authentication.xml file and uncomment the configuration if you want to control the request parameters that are going to the authentication endpoint. Otherwise skip this step.

 	<!-- 
        AuthenticationEndpointQueryParams are the request parameters 
        that would be sent to the AuthenticationEndpoint. 
        'action' defines the behaviour: if 'include', only the defined 
        parameters would be included in the request. 
        If 'exclude' specified, all the parameters received by the 
        Authentication Framework would be sent in the request except 
        the ones specified. 
        'sessionDataKey', 'type', 'relyingParty', 'sp' and 'authenticators' 
        parameters will be always sent. They should not be specified here.  
    -->
    <!--AuthenticationEndpointQueryParams action="exclude"-->
        <!--AuthenticationEndpointQueryParam name="username"/-->
        <!--AuthenticationEndpointQueryParam name="password"/-->
    <!--/AuthenticationEndpointQueryParams-->

	NOTE: "username" and "password" are given only as examples

(viii) You need to create the following additional table in the database that has been referred by <CARBON_SERVER>/repository/conf/identity.xml file.

Following is the tested SQL script that is needed to execute in MySQL database.

	CREATE TABLE IDN_AUTH_SESSION_STORE (
			SESSION_ID varchar(100) default NULL, 
			SESSION_TYPE varchar(100) default NULL, 
			SESSION_OBJECT BLOB, 
			TIME_CREATED TIMESTAMP, 
			PRIMARY KEY (SESSION_ID, SESSION_TYPE), 
			UNIQUE(SESSION_ID, SESSION_TYPE)
	) ENGINE INNODB;

Following is the tested SQL script that is needed to execute in Oracle database.

	CREATE TABLE IDN_AUTH_SESSION_STORE (
		    SESSION_ID VARCHAR (100) DEFAULT NULL,
		    SESSION_TYPE VARCHAR(100) DEFAULT NULL,
		    SESSION_OBJECT BLOB,
		    TIME_CREATED TIMESTAMP,
		    PRIMARY KEY (SESSION_ID, SESSION_TYPE))

You can configure following parameters in the <CARBON_SERVER>/repository/conf/identity.xml file under the <JDBCPersistenceManager>

	<SessionDataPersist>
		<Enable>true</Enable>
		<RememberMePeriod>20160</RememberMePeriod>
		<CleanUp>
			<Enable>true</Enable>
			<!--Period>1</Period>
			<TimeOut>2</TimeOut-->
		</CleanUp>
		<Temporary>false</Temporary>
	</SessionDataPersist>

Enable  :  This would enable the persistence of data. Therefore, you need to configure this to "true"
RememberMePeriod : Time Period (In minutes) that remember me option should be valid. (after this time period user will be logged out even if he enables remember me. Default value is 2 weeks)
CleanUp :  Session data cleanup configuration.
               Enable - Enable the cleanup task running
               Period (In minutes) -  Time Period that cleanup task would run  (Default value is 1 day)
               TimeOut (In mintues) - Time out value of the session data that would be removed by the cleanup task. (default value is 2 weeks)
Temporary: Enable persistance of temporary caches that are created within an authentication request.

Apply following configuration under "Server" (element which is the root element) 

	<SessionContextCache> 
		<Enable>true</Enable> 
		<Capacity>100000</Capacity>	
	</SessionContextCache>

(ix) If you are using the existing database, execute the follwoig SQL query to change the super tenant LOCAL IDP default Authenticator name from 'saml2sso' to 'samlsso'

	UPDATE IDP_AUTHENTICATOR
	SET NAME='samlsso'
	WHERE NAME = 'saml2sso' AND TENANT_ID = '-1234'

	If you are using a fresh database you do not need to run this SQL query.

(x)  Add the ThriftHostName element to the repository/conf/identity.xml as mentioned below. 
     Within the ThriftHostName element you have to mention the host name of the machine where IS node operates.
     Copy and paste the <ThriftHostName> configuration in to identity.xml under //Server/EntitlementSettings/ThirftBasedEntitlementConfig

	<ThirftBasedEntitlementConfig>
		<EnableThriftService>true</EnableThriftService>
		<!-- Enable this element to mention the host-name of your IS machine -->
		<!--ThriftHostName>is.wso2.com</ThriftHostName-->
		<ReceivePort>${Ports.ThriftEntitlementReceivePort}</ReceivePort>
		<ClientTimeout>10000</ClientTimeout>
		<KeyStore>
			<Location>wso2carbon.jks</Location>
			<Password>wso2carbon</Password>
		</KeyStore>
	</ThirftBasedEntitlementConfig>

(xi) Restart the server with :
       Linux/Unix :  sh wso2server.sh
       Windows    :  wso2server.bat

[1] https://docs.wso2.com/display/IS500/Error+Codes+and+Descriptions 

